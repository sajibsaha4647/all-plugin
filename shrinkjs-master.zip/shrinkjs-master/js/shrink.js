/*
 * Shrink.js v0.0.2
 * Copyright (c) 2015 Jari Jokinen. MIT License.
 */

$(document).ready(function() {
  $(window).scroll(function() {
    if ($(window).scrollTop() > 150) {
      $('.navbar').addClass('navbar-small');
      $('.navbar').removeClass('navbar-large');
    }
    else {
      $('.navbar').addClass('navbar-large');
      $('.navbar').removeClass('navbar-small');
    }
  });
});
