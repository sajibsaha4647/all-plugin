# Shrink.js

Shrink.js shrinks the navbar when user scrolls down the page.

## Requirements

* jQuery
* Twitter Bootstrap

## Usage

Load stylesheet and JavaScript:

    <link rel="stylesheet" style="shrink.css" />
    <script src="shrink.js"></script>

Add navbar-large class to your navbar:

    <nav class="navbar navbar-default navbar-fixed-top navbar-large">
      ...
    </nav>

## Support

If you have any questions or issues with Shrink.js, or if you like to report a
bug, please create an [issue on
GitHub](https://github.com/jarijokinen/shrinkjs/issues).

## License

MIT License. Copyright (c) 2015 [Jari Jokinen](http://jarijokinen.com). See
[LICENSE](https://github.com/jarijokinen/shrinkjs/blob/master/LICENSE.txt) for
further details.
