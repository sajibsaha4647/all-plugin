# Changelog

## 0.0.2 (April 27, 2015)

* Fix navbar-brand padding

## 0.0.1 (April 26, 2015)

* Initial release
